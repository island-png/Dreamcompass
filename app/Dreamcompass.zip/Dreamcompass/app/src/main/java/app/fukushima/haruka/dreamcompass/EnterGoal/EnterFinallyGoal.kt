package app.fukushima.haruka.dreamcompass.EnterGoal
data class EnterFinallyGoal(val name: String){
}