package app.fukushima.haruka.dreamcompass.FeedBack

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.databinding.FragmentSelectTomorrowTodoBinding
import app.fukushima.haruka.dreamcompass.databinding.FragmentTodaysReviewBinding

class TomorrowTodoFragment : Fragment(R.layout.fragment_select_tomorrow_todo) {
    private var _binding: FragmentSelectTomorrowTodoBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentSelectTomorrowTodoBinding.bind(view)

        // TODO: button2 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonOk.setOnClickListener {
            findNavController().navigate(R.id.action_tomorrowTodoFragmemt_to_todayTodoFragment)
        }
    }
}