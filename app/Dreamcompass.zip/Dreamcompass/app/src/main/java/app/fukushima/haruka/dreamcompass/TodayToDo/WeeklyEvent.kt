package app.fukushima.haruka.dreamcompass.TodayToDo

data class WeeklyEvent (val name:String)