package app.fukushima.haruka.dreamcompass.WeeklyToDo
data class WeeklyToDo(val name: String)