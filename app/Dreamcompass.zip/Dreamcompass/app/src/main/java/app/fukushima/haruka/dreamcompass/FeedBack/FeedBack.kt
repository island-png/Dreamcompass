package app.fukushima.haruka.dreamcompass.FeedBack

class FeedBack  (var todayAchievement:Int)