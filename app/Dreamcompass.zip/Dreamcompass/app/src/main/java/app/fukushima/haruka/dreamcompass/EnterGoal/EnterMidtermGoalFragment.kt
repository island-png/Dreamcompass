package app.fukushima.haruka.dreamcompass.EnterGoal

import androidx.fragment.app.Fragment
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.R

import app.fukushima.haruka.dreamcompass.databinding.EnterMidtermGoalBinding

class EnterMidtermGoalFragment :Fragment(R.layout.enter_midterm_goal) {
    private var _binding: EnterMidtermGoalBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = EnterMidtermGoalBinding.bind(view)

        binding.buttonOK3.setOnClickListener {
            findNavController().navigate(R.id.action_enterMidtermGoalFragment_to_GoalFragment)
        }
    }



}