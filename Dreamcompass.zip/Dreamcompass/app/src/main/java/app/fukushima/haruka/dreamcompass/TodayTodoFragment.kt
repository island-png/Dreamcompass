package app.fukushima.haruka.dreamcompass

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.databinding.FragmentTodayTodoBinding

class TodayTodoFragment : Fragment(R.layout.fragment_today_todo) {

    private var _binding: FragmentTodayTodoBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentTodayTodoBinding.bind(view)

        // TODO: button2 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonCenter.setOnClickListener {
            findNavController().navigate(R.id.action_TodayTodoFragment_to_GoalFragment)
        }
        // TODO: button3 も同じく名前を考えよう！
        binding.buttonLeft.setOnClickListener {
            findNavController().navigate(R.id.action_TodayTodoFragment_to_WeeklyTodoFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}