package app.fukushima.haruka.dreamcompass.Goal

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.databinding.FragmentGoalBinding

class GoalFragment : Fragment(R.layout.fragment_goal) {

    private var _binding: FragmentGoalBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentGoalBinding.bind(view)

        // TODO: button1 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonRight.setOnClickListener {
            findNavController().navigate(R.id.action_GoalFragment_to_TodayTodoFragment)
        }
        // TODO: button3 も同じく名前を考えよう！
        binding.buttonLeft.setOnClickListener {
            findNavController().navigate(R.id.action_GoalFragment_to_WeeklyTodoFragment)
        }
        binding.buttonUpdateFinally.setOnClickListener {
            findNavController().navigate(R.id.action_GoalFragment_to_enterFinallyGoalFragment)
        }
        binding.buttonUpdatemidterm.setOnClickListener {
            findNavController().navigate(R.id.action_GoalFragment_to_enterMidtermGoalFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}