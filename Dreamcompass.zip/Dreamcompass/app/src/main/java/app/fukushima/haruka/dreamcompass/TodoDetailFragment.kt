package app.fukushima.haruka.dreamcompass

import android.app.DatePickerDialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.DatePicker
import android.widget.Spinner
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.databinding.FragmentTodoDetailBinding

class TodoDetailFragment : Fragment(R.layout.fragment_todo_detail),
    DatePickerDialog.OnDateSetListener {

    private var _binding: FragmentTodoDetailBinding? = null
    private val binding get() = _binding!!

    private val spinnerSituationItems = arrayOf("未学習", "学習中", "学習済み")
    private val spinnerPriorityItems = arrayOf("☆", "☆☆", "☆☆☆")



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentTodoDetailBinding.bind(view)

        // TODO: SharedPreferences はアプリ内で共通のものを1つ使うので、名前は "TODO_STORE" のような「Todo を保存するための場所」という意味にすると良さそう！
        val pref: SharedPreferences =
            requireActivity().getSharedPreferences("TODO_STORE", Context.MODE_PRIVATE)



        val situationAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            spinnerSituationItems
        )
        situationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSituation.adapter = situationAdapter
        var situation = ""
        binding.spinnerSituation.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            //　アイテムが選択された時
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?, position: Int, id: Long
            ) {
                val spinnerParent = parent as Spinner
                val item = spinnerParent.selectedItem as String
                situation = item
            }

            //　アイテムが選択されなかった
            override fun onNothingSelected(parent: AdapterView<*>?) {
                //
            }
        }


        val priorityAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            spinnerPriorityItems
        )
        priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPriority.adapter = priorityAdapter
        var priority=""
        binding.spinnerPriority.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            //　アイテムが選択された時
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?, position: Int, id: Long
            ) {
                val spinnerParent = parent as Spinner
                val item = spinnerParent.selectedItem as String
                // View Binding
                priority= item
            }

            //　アイテムが選択されなかった
            override fun onNothingSelected(parent: AdapterView<*>?) {
                //
            }
        }



        // TODO: button1 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonOk.setOnClickListener {
            // pref に書き込むための editor を作成
            val editor = pref.edit()
            // キーと、それに対応する保存したい値を editor に登録する
            editor.putString("WEEKLY_TODO", binding.editText1.text.toString())
            editor.putString("SITUATION_KEY", situation)
            editor.putString("PRIORITY_KEY", priority)

            // 実際に editor が書き込み処理を実行する
            editor.apply()

            findNavController().navigate(R.id.action_toDoDetailFragment_to_WeeklyTodoFragment)
        }
        binding.datePickButton.setOnClickListener{
            // DatePick().show(requireActivity().supportFragmentManager,"date set")
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        Log.d("あああ", "date set")

    }
}




