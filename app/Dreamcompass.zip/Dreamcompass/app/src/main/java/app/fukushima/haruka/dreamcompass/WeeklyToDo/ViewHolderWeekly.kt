package app.fukushima.haruka.dreamcompass.WeeklyToDo

import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.databinding.ItemDataCellWeekBinding

class ViewHolderWeekly(val binding: ItemDataCellWeekBinding): RecyclerView.ViewHolder(binding.root)