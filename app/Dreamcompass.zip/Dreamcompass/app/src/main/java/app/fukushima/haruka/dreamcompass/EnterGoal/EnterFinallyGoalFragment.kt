package app.fukushima.haruka.dreamcompass.EnterGoal

import androidx.fragment.app.Fragment
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.databinding.EnterFinallyGoalBinding

class EnterFinallyGoalFragment :Fragment(R.layout.enter_finally_goal) {
    private var _binding: EnterFinallyGoalBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = EnterFinallyGoalBinding.bind(view)

        binding.buttonOK2.setOnClickListener {
            findNavController().navigate(R.id.action_enterFinallyGoalFragment_to_GoalFragment)
        }
    }



}