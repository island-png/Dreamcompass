package app.fukushima.haruka.dreamcompass.TodayToDo

import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.databinding.ItemDetaCellWeeklyEventBinding

class ViewHolderWeeklyEvent(val binding: ItemDetaCellWeeklyEventBinding): RecyclerView.ViewHolder(binding.root)