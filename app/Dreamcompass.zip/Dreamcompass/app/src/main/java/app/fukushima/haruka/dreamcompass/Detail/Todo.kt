package app.fukushima.haruka.dreamcompass.Detail

import android.widget.Spinner

class Todo (var title:String, var until:Int,var priority:String,var situation:String,var category:String,var DoDay:Int)