package app.fukushima.haruka.dreamcompass.TodayToDo

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.WeeklyEvent.ListAdapterWeeklyEvent
import app.fukushima.haruka.dreamcompass.databinding.FragmentTodayTodoBinding

class TodayTodoFragment : Fragment(R.layout.fragment_today_todo) {

    private var _binding: FragmentTodayTodoBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentTodayTodoBinding.bind(view)

        // TODO: button2 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonCenter.setOnClickListener {
            findNavController().navigate(R.id.action_TodayTodoFragment_to_GoalFragment)
        }
        // TODO: button3 も同じく名前を考えよう！
        binding.buttonLeft.setOnClickListener {
            findNavController().navigate(R.id.action_TodayTodoFragment_to_WeeklyTodoFragment)
        }
        binding.enterFeedback.setOnClickListener {
            findNavController().navigate(R.id.action_TodayTodoFragment_to_todaysReviewFragment)
        }
        val todos = listOf<TodayToDo>(
            TodayToDo("english"),
            TodayToDo("mathematics"),
            )
        val event = listOf<WeeklyEvent>(
            WeeklyEvent("模試"),
            WeeklyEvent("数検"),

            )

        // 上で用意したAdapterの利用
        val adapter = ListAdapterToday()
        adapter.updateList(todos)

        // RecyclerViewとAdapterを連携させる
        binding.homeRecyclerView.adapter = adapter

        // レイアウトの設定
        // スクロール方向を縦向きで作成（デフォルト）
        binding.homeRecyclerView.layoutManager = LinearLayoutManager(context)

        val adapterWeeklyEvent = ListAdapterWeeklyEvent()
        adapterWeeklyEvent.updateList(event)

        // RecyclerViewとAdapterを連携させる
        binding.homeRecyclerWeeklyEventView.adapter = adapterWeeklyEvent

        // レイアウトの設定
        // スクロール方向を縦向きで作成（デフォルト）
        binding.homeRecyclerWeeklyEventView.layoutManager = LinearLayoutManager(context)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}