package app.fukushima.haruka.dreamcompass.TodayToDo

import app.fukushima.haruka.dreamcompass.TodayToDo.TodayToDo
import app.fukushima.haruka.dreamcompass.TodayToDo.ViewHolderToday
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.databinding.ItemDetaCellTodayBinding

class ListAdapterToday: RecyclerView.Adapter<ViewHolderToday>() {

    private val TodoList: MutableList<TodayToDo> = mutableListOf()

    // ViewHolderの作成
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderToday {
        val binding = ItemDetaCellTodayBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolderToday(binding)
    }

    // ViewHolderの設定
    override fun onBindViewHolder(holder: ViewHolderToday, position: Int) {
        val todo = TodoList[position]
        holder.binding.itemTextView.text = todo.name
    }

    // ViewHolderの数の決定
    override fun getItemCount(): Int = TodoList.size

    fun updateList(newList: List<TodayToDo>) {
        TodoList.clear()
        TodoList.addAll(newList)
        notifyDataSetChanged()
    }




}