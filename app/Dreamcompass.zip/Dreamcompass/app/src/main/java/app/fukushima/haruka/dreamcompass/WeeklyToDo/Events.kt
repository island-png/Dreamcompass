package app.fukushima.haruka.dreamcompass.WeeklyToDo

class Events  (var context:String,var day:Int)