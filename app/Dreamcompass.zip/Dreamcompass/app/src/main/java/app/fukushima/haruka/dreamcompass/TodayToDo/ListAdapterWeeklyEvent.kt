package app.fukushima.haruka.dreamcompass.WeeklyEvent

import app.fukushima.haruka.dreamcompass.WeeklyEvent.ListAdapterWeeklyEvent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.TodayToDo.ViewHolderWeeklyEvent
import app.fukushima.haruka.dreamcompass.TodayToDo.WeeklyEvent
import app.fukushima.haruka.dreamcompass.databinding.ItemDetaCellWeeklyEventBinding

class ListAdapterWeeklyEvent: RecyclerView.Adapter<ViewHolderWeeklyEvent>() {

    private val TodoList: MutableList<WeeklyEvent> = mutableListOf()

    // ViewHolderの作成
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderWeeklyEvent {
        val binding = ItemDetaCellWeeklyEventBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolderWeeklyEvent(binding)
    }

    // ViewHolderの設定
    override fun onBindViewHolder(holder: ViewHolderWeeklyEvent, position: Int) {
        val todo = TodoList[position]
        holder.binding.itemTextView.text = todo.name
    }

    // ViewHolderの数の決定
    override fun getItemCount(): Int = TodoList.size

    fun updateList(newList: List<WeeklyEvent>) {
        TodoList.clear()
        TodoList.addAll(newList)
        notifyDataSetChanged()
    }




}