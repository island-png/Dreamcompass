package app.fukushima.haruka.dreamcompass.WeeklyToDo

import android.content.ContentValues.TAG
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.databinding.FragmentWeeklyTodoBinding
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.auth.User
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import org.checkerframework.checker.units.qual.s
import com.firebase.ui.firestore.FirestoreRecyclerOptions




class WeeklyTodoFragment : Fragment(R.layout.fragment_weekly_todo) {


    private var _binding: FragmentWeeklyTodoBinding? = null
    private val binding get() = _binding!!

    val db = Firebase.firestore
    //val db = FirebaseFirestore.getInstance()
    val query = db.collection("users").orderBy("firstName", Query.Direction.ASCENDING)

    //Firebase UI を入れる事で使用可能に
    val options = FirestoreRecyclerOptions.Builder<User>().setQuery(query, User::class.java).build()


    // View の操作をする
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentWeeklyTodoBinding.bind(view)

        // Create a new user with a first and last name
        // Create a new user with a first and last name
        val user: MutableMap<String, Any> = HashMap()
        user["first"] = "Ada"
        user["last"] = "Lovelace"
        user["born"] = 1815



// Add a new document with a generated ID
//        db.collection("users")
//            .add(user)
//            .addOnSuccessListener {it ->
//                Log.d(TAG, "DocumentSnapshot added with ID: " + it.id)
//
//            }.addOnFailureListener(OnFailureListener { e ->
//                Log.w(TAG, "Error adding document", e)
//            })

        db.collection("users")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    for (document in task.result) {


                        Log.d(TAG, document.id + " => " + document.data)
                    }
                } else {
                    Log.w(TAG, "Error getting documents.", task.exception)
                }
            }




        // TODO: button1 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonRight.setOnClickListener {
            Log.d("あああ", "button_right clicked")
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_TodayTodoFragment)
        }
        // TODO: button2 も同じく名前を考えよう！
        binding.buttonCenter.setOnClickListener {
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_GoalFragment)
        }
        // TODO: button4 も同じく名前を考えよう！
        binding.buttonNewitem.setOnClickListener {
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_todoDetailFragment)
        }

        // データの配列
        // 4つあるので、4個の花が一覧で表示される
        val todos = listOf<WeeklyToDo>(
            WeeklyToDo("english"),
            WeeklyToDo("mathematics"),

            )
        db.collection("users")
            .add(user)
            .addOnSuccessListener { documentReference ->
                Log.d(
                    TAG,
                    "DocumentSnapshot added with ID: " + documentReference.id
                )

            }
            .addOnFailureListener { e -> Log.w(TAG, "Error adding document", e) }

        // 上で用意したAdapterの利用
        val adapter = ListAdapterWeekly(options)
        adapter.updateList(todos)

        // RecyclerViewとAdapterを連携させる
        binding.homeRecyclerView.adapter = adapter

        // レイアウトの設定
        // スクロール方向を縦向きで作成（デフォルト）
        binding.homeRecyclerView.layoutManager = LinearLayoutManager(context)







        // TODO: SharedPreferences はアプリ内で共通のものを1つ使うので、名前は "TODO_STORE"（定数） のような「Todo を保存するための場所」という意味にすると良さそう！
        val pref: SharedPreferences = requireActivity().getSharedPreferences("TODO_STORE", Context.MODE_PRIVATE)
        Log.d("おおお", "button_ok clicked")

        // TODO: 一時的な変数ではあるけど str だと何の文字列だか分からないので、できる限り「何の文字列か」が分かる名前を考えよう！
        // TODO: 第1引数に渡す key の値も、何のデータだかを示すような名前にしよう！例えば「毎週の Todo」を表すとしたら "WEEKLY_TODO" のような key にしよう！
        val weeklyToDo = pref.getString("WEEKLY_TODO", "NoData")
        //binding.itemTextView.text = weeklyToDo

    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private inner class UserViewHolder internal constructor(private val view: View) : RecyclerView.ViewHolder(view){
        internal fun setUserName(firstName: String, lastName: String){

            val textviewFirst = view.findViewById<TextView>(R.id.itemTextView)
            textviewFirst.text = firstName

            val textviewLast = view.findViewById<TextView>(R.id.itemTextView)
            textviewLast.text = lastName

        }
    }
    val adapter = ListAdapterWeekly(options)

    override fun onStart() {
        super.onStart()
        adapter!!.startListening()
    }
    override fun onStop() {
        super.onStop()

        if (adapter != null) {
            adapter!!.stopListening()
        }
    }


}



