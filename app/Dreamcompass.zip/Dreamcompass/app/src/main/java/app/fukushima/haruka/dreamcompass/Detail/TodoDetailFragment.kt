package app.fukushima.haruka.dreamcompass.Detail

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.ContentValues.TAG
import android.content.Context
import android.content.SharedPreferences
import android.icu.util.Calendar
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.widget.*
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.R
import app.fukushima.haruka.dreamcompass.databinding.FragmentTodoDetailBinding
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.time.LocalDate
import java.time.format.DateTimeFormatter


class TodoDetailFragment : Fragment(R.layout.fragment_todo_detail),
    DatePickerDialog.OnDateSetListener {

    private var _binding: FragmentTodoDetailBinding? = null
    private val binding get() = _binding!!

    private val spinnerSituationItems = arrayOf("未学習", "学習中", "学習済み")
    private val spinnerPriorityItems = arrayOf("☆", "☆☆", "☆☆☆")



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentTodoDetailBinding.bind(view)
        // Create a new user with a first and last name
        // Create a new user with a first and last name
        val user: MutableMap<String, Any> = HashMap()
        user["first"] = "Ada"
        user["last"] = "Lovelace"
        user["born"] = 1815

// Add a new document with a generated ID

// Add a new document with a generated ID
        val db = Firebase.firestore
        db.collection("users")
            .add(user)
            .addOnSuccessListener(OnSuccessListener<DocumentReference> { documentReference ->
                Log.d(
                    TAG,
                    "DocumentSnapshot added with ID: " + documentReference.id
                )
            })
            .addOnFailureListener(OnFailureListener { e -> Log.w(TAG, "Error adding document", e) })



        // TODO: SharedPreferences はアプリ内で共通のものを1つ使うので、名前は "TODO_STORE" のような「Todo を保存するための場所」という意味にすると良さそう！
        val pref: SharedPreferences =
            requireActivity().getSharedPreferences("TODO_STORE", Context.MODE_PRIVATE)

        val situationAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            spinnerSituationItems

        )
        situationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSituation.adapter = situationAdapter
        var situation = ""
        binding.spinnerSituation.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            //　アイテムが選択された時
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?, position: Int, id: Long
            ) {
                val spinnerParent = parent as Spinner
                val item = spinnerParent.selectedItem as String
                situation = item
                Log.d("学習状況", "button_situation clicked")

            }

            //　アイテムが選択されなかった
            override fun onNothingSelected(parent: AdapterView<*>?) {
                //
            }
        }


        val priorityAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            spinnerPriorityItems
        )
        priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPriority.adapter = priorityAdapter
        var priority=""
        binding.spinnerPriority.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            //　アイテムが選択された時
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?, position: Int, id: Long
            ) {
                val spinnerParent = parent as Spinner
                val item = spinnerParent.selectedItem as String
                // View Binding
                priority= item
                Log.d("優先度", "button_situation clicked")

            }

            //　アイテムが選択されなかった
            override fun onNothingSelected(parent: AdapterView<*>?) {
                //
            }
        }



        // TODO: button1 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonOk.setOnClickListener {
            // pref に書き込むための editor を作成
            val editor = pref.edit()
            // キーと、それに対応する保存したい値を editor に登録する
            editor.putString("WEEKLY_TODO", binding.editText1.text.toString())
            editor.putString("SITUATION_KEY", situation)
            editor.putString("PRIORITY_KEY", priority)

            // 実際に editor が書き込み処理を実行する
            editor.apply()

            findNavController().navigate(R.id.action_toDoDetailFragment_to_WeeklyTodoFragment)
        }


        //現在日付を取得
        val current = LocalDate.now()
        //表示する際のフォーマットを決める
        val formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E)")
        //現在日付をフォーマットに合わせる
        val dateFormat = current.format(formatter)

        //キーボードを表示させない
        binding.datePickButton.setRawInputType(InputType.TYPE_NULL)
        //EditTextに現在日付を表示
        binding.datePickButton.setText(dateFormat.toString())

        /**
         * 日付の変更
         * 値：選択された日付
         * 表示：yyyy年MM月dd日(E)
         */

        binding.datePickButton.setOnClickListener{
            val datePicker = DatePickerFragment(binding.datePickButton)
            //FragmentManagerを取得する
            val fragmentManager = requireActivity().supportFragmentManager
            //DatePickerを表示
            datePicker.show(fragmentManager,"DatePickerDialog")
        }


    }

    class DatePickerFragment(private val editText: EditText): DialogFragment(),
        DatePickerDialog.OnDateSetListener{

        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

            //Calender()を取得
            val calendar: Calendar = Calendar.getInstance()
            //年を示すフィールドの値を取得
            val year = calendar.get(Calendar.YEAR)
            //月を示すフィールドの値を取得
            val month = calendar.get(Calendar.MONTH)
            //日を示すフィールドの値を取得
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            //指定された日付でDatePickerを作成して返す
            return DatePickerDialog(
                requireContext(),
                this,
                year,
                month,
                day
            )
        }

        //日付選択がされた時の処理
        override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
            //DatePickerにて選択された日付(年月日)をもとにLocalDateのインスタンスを取得
            val setLocalDate = LocalDate.of(year,month+1,dayOfMonth)
            //表示する際のフォーマットを決める
            val format = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E)")
            //選択された日付をフォーマットに合わせる
            val date = setLocalDate.format(format)
            //editTextに表示させる
            editText.setText(date)
        }

    }



    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        Log.d("あああ", "date set")

    }

}




