package app.fukushima.haruka.dreamcompass

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import app.fukushima.haruka.dreamcompass.databinding.FragmentWeeklyTodoBinding

class WeeklyTodoFragment : Fragment(R.layout.fragment_weekly_todo) {

    private var _binding: FragmentWeeklyTodoBinding? = null
    private val binding get() = _binding!!

    // View の操作をする
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentWeeklyTodoBinding.bind(view)

        // TODO: button1 だと何をするボタンか分かりにくくなってしまうので、何をするボタンか説明となるような名前をつけよう！
        binding.buttonRight.setOnClickListener {
            Log.d("あああ", "button_right clicked")
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_TodayTodoFragment)
        }
        // TODO: button2 も同じく名前を考えよう！
        binding.buttonCenter.setOnClickListener {
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_GoalFragment)
        }
        // TODO: button4 も同じく名前を考えよう！
        binding.buttonNewitem.setOnClickListener {
            findNavController().navigate(R.id.action_WeeklyTodoFragment_to_todoDetailFragment)
        }

        // TODO: SharedPreferences はアプリ内で共通のものを1つ使うので、名前は "TODO_STORE"（定数） のような「Todo を保存するための場所」という意味にすると良さそう！
        val pref: SharedPreferences = requireActivity().getSharedPreferences("TODO_STORE", Context.MODE_PRIVATE)
        // TODO: 一時的な変数ではあるけど str だと何の文字列だか分からないので、できる限り「何の文字列か」が分かる名前を考えよう！
        // TODO: 第1引数に渡す key の値も、何のデータだかを示すような名前にしよう！例えば「毎週の Todo」を表すとしたら "WEEKLY_TODO" のような key にしよう！
        val weeklyToDo = pref.getString("WEEKLY_TODO", "NoData")
        binding.mockTextView.text = weeklyToDo
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}