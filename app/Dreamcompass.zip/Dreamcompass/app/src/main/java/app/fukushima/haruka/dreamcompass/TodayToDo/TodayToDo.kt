package app.fukushima.haruka.dreamcompass.TodayToDo

data class TodayToDo (val name:String)