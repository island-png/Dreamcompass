package app.fukushima.haruka.dreamcompass.Goal

class Goals (var content:String,var whatToDo:String,var until:Int)