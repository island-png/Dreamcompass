package app.fukushima.haruka.dreamcompass

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import app.fukushima.haruka.dreamcompass.databinding.ActivityMainBinding

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContentView(R.layout.activity_main)
    }
}