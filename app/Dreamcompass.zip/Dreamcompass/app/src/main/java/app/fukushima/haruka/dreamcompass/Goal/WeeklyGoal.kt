package app.fukushima.haruka.dreamcompass.Goal

class WeeklyGoal (var context:String,var whatToDo:String)