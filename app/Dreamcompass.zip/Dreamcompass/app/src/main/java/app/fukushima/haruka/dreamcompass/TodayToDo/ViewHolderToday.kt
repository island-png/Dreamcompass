package app.fukushima.haruka.dreamcompass.TodayToDo

import androidx.recyclerview.widget.RecyclerView
import app.fukushima.haruka.dreamcompass.databinding.ItemDetaCellTodayBinding

class ViewHolderToday(val binding: ItemDetaCellTodayBinding): RecyclerView.ViewHolder(binding.root)